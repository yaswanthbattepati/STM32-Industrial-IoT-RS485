#include <Arduino.h>
#include <Wire.h>

// =====================================================
// RS485 UART
// RX = PA10 / D0
// TX = PA9  / D1
// =====================================================

HardwareSerial RS485Serial(PA10, PA9);

// =====================================================
// PIN DEFINITIONS
// =====================================================

#define SENSOR_PIN   A0
#define BUTTON_PIN   A1

#define GREEN_LED    D3
#define YELLOW_LED   D6
#define RED_LED      D12

#define RS485_DIR    D2

// Sensor Node:  D13 -> 3.3V
// Monitor Node: D13 -> GND
#define ROLE_PIN     D13

#define LCD_ADDR     0x27

// =====================================================
// GLOBAL VARIABLES
// =====================================================

bool sensorNode = false;

volatile bool buttonPressed = false;

int adcValue = 0;
int level = 0;

// =====================================================
// BUTTON INTERRUPT
// =====================================================

void buttonISR()
{
  buttonPressed = true;
}

// =====================================================
// LCD FUNCTIONS
// =====================================================

void lcdWrite(uint8_t data)
{
  Wire.beginTransmission(LCD_ADDR);
  Wire.write(data);
  Wire.endTransmission();
}

void lcdPulse(uint8_t data)
{
  lcdWrite(data | 0x04);

  delayMicroseconds(1);

  lcdWrite(data & ~0x04);

  delayMicroseconds(50);
}

void lcdSend(uint8_t value, uint8_t mode)
{
  uint8_t highNibble =
    (value & 0xF0) | mode | 0x08;

  uint8_t lowNibble =
    ((value << 4) & 0xF0) | mode | 0x08;

  lcdPulse(highNibble);
  lcdPulse(lowNibble);
}

void lcdCommand(uint8_t command)
{
  lcdSend(command, 0);
}

void lcdCharacter(char character)
{
  lcdSend(character, 1);
}

void lcdPrint(const char *text)
{
  while (*text)
  {
    lcdCharacter(*text);
    text++;
  }
}

void lcdClear()
{
  lcdCommand(0x01);
  delay(2);
}

void lcdSetCursor(uint8_t column, uint8_t row)
{
  uint8_t address;

  if (row == 0)
    address = column;
  else
    address = 0x40 + column;

  lcdCommand(0x80 | address);
}

void lcdInit()
{
  delay(50);

  lcdPulse(0x30);
  delay(5);

  lcdPulse(0x30);
  delayMicroseconds(150);

  lcdPulse(0x30);
  delayMicroseconds(150);

  lcdPulse(0x20);

  lcdCommand(0x28);
  lcdCommand(0x0C);
  lcdCommand(0x06);

  lcdClear();
}

// =====================================================
// LCD NUMBER
// =====================================================

void lcdNumber(int number)
{
  if (number >= 100)
    lcdCharacter('1');

  if (number >= 10)
    lcdCharacter(
      '0' + ((number / 10) % 10)
    );

  lcdCharacter(
    '0' + (number % 10)
  );
}

// =====================================================
// SENSOR STATE
// =====================================================

const char* getState(int percentage)
{
  if (percentage <= 30)
    return "NORMAL";

  if (percentage <= 70)
    return "WARNING";

  return "ALERT";
}

// =====================================================
// LED CONTROL
// =====================================================

void updateLEDs(int percentage)
{
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(YELLOW_LED, LOW);
  digitalWrite(RED_LED, LOW);

  if (percentage <= 30)
  {
    digitalWrite(GREEN_LED, HIGH);
  }
  else if (percentage <= 70)
  {
    digitalWrite(YELLOW_LED, HIGH);
  }
  else
  {
    digitalWrite(RED_LED, HIGH);
  }
}

// =====================================================
// LOCAL SENSOR LCD
// =====================================================

void displaySensor()
{
  lcdClear();

  lcdSetCursor(0, 0);

  lcdPrint("LEVEL: ");

  lcdNumber(level);

  lcdCharacter('%');

  lcdSetCursor(0, 1);

  lcdPrint("STATUS:");

  lcdPrint(getState(level));
}

// =====================================================
// RS485 TRANSMIT
// =====================================================

void transmitData()
{
  // Enable transmitter
  digitalWrite(RS485_DIR, HIGH);

  delayMicroseconds(100);

  // Packet:
  // N1,ADC,LEVEL,STATE

  RS485Serial.print("N1,");
  RS485Serial.print(adcValue);
  RS485Serial.print(",");
  RS485Serial.print(level);
  RS485Serial.print(",");
  RS485Serial.println(getState(level));

  RS485Serial.flush();

  delayMicroseconds(100);

  // Enable receiver
  digitalWrite(RS485_DIR, LOW);
}

// =====================================================
// RS485 RECEIVE
// =====================================================

void receiveData()
{
  static char buffer[50];

  static byte index = 0;

  while (RS485Serial.available())
  {
    char received =
      RS485Serial.read();

    if (received == '\n')
    {
      buffer[index] = '\0';

      Serial.print("RS485 RX: ");
      Serial.println(buffer);

      // Check packet
      if (
        buffer[0] == 'N' &&
        buffer[1] == '1' &&
        buffer[2] == ','
      )
      {
        int position = 3;

        // Skip ADC
        while (
          buffer[position] != ',' &&
          buffer[position] != '\0'
        )
        {
          position++;
        }

        if (buffer[position] == ',')
          position++;

        // Read level
        int remoteLevel = 0;

        while (
          buffer[position] >= '0' &&
          buffer[position] <= '9'
        )
        {
          remoteLevel =
            remoteLevel * 10 +
            buffer[position] - '0';

          position++;
        }

        if (buffer[position] == ',')
          position++;

        // LCD
        lcdClear();

        lcdSetCursor(0, 0);

        lcdPrint("REMOTE: ");

        lcdNumber(remoteLevel);

        lcdCharacter('%');

        lcdSetCursor(0, 1);

        if (buffer[position] == 'N')
        {
          lcdPrint("NORMAL");
        }
        else if (buffer[position] == 'W')
        {
          lcdPrint("WARNING");
        }
        else
        {
          lcdPrint("ALERT");
        }

        // LEDs
        updateLEDs(remoteLevel);

        Serial.println("VALID RS485 DATA");
      }

      index = 0;
    }
    else
    {
      if (index < 49)
      {
        buffer[index] = received;
        index++;
      }
      else
      {
        index = 0;
      }
    }
  }
}

// =====================================================
// SENSOR NODE SETUP
// =====================================================

void setupSensorNode()
{
  Serial.println();
  Serial.println("==============================");
  Serial.println("STM32 RS485 SENSOR NODE");
  Serial.println("==============================");

  analogReadResolution(12);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(BUTTON_PIN),
    buttonISR,
    FALLING
  );

  pinMode(RS485_DIR, OUTPUT);

  digitalWrite(RS485_DIR, LOW);

  Wire.begin();

  lcdInit();

  lcdSetCursor(0, 0);
  lcdPrint("SENSOR NODE");

  lcdSetCursor(0, 1);
  lcdPrint("READY");

  delay(1000);

  lcdClear();

  Serial.println("ADC: 12-bit");
  Serial.println("RS485: 9600 baud");
  Serial.println("TX: PA9");
  Serial.println("RX: PA10");
}

// =====================================================
// MONITOR NODE SETUP
// =====================================================

void setupMonitorNode()
{
  Serial.println();
  Serial.println("==============================");
  Serial.println("STM32 RS485 MONITOR NODE");
  Serial.println("==============================");

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  pinMode(RS485_DIR, OUTPUT);

  digitalWrite(RS485_DIR, LOW);

  Wire.begin();

  lcdInit();

  lcdSetCursor(0, 0);
  lcdPrint("RS485 MONITOR");

  lcdSetCursor(0, 1);
  lcdPrint("WAITING...");

  Serial.println("Monitor Node Ready");
  Serial.println("Waiting for RS485 data...");
}

// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(115200);

  delay(500);

  // RS485 UART
  RS485Serial.begin(9600);

  delay(100);

  // Select node
  pinMode(ROLE_PIN, INPUT);

  delay(50);

  if (digitalRead(ROLE_PIN) == HIGH)
    sensorNode = true;
  else
    sensorNode = false;

  if (sensorNode)
    setupSensorNode();
  else
    setupMonitorNode();
}

// =====================================================
// SENSOR LOOP
// =====================================================

void sensorLoop()
{
  // Read sensor
  adcValue = analogRead(SENSOR_PIN);

  // ADC → percentage
  level = map(
    adcValue,
    0,
    4095,
    0,
    100
  );

  // LEDs
  updateLEDs(level);

  // LCD
  displaySensor();

  // Serial monitor
  Serial.print("ADC=");
  Serial.print(adcValue);

  Serial.print(" LEVEL=");
  Serial.print(level);

  Serial.print("% STATE=");
  Serial.println(getState(level));

  // Send RS485
  transmitData();

  // Button interrupt
  if (buttonPressed)
  {
    buttonPressed = false;

    Serial.println("BUTTON PRESSED");

    lcdClear();

    lcdSetCursor(0, 0);
    lcdPrint("BUTTON PRESSED");

    lcdSetCursor(0, 1);
    lcdPrint("SYSTEM ACTIVE");

    delay(500);
  }

  delay(1000);
}

// =====================================================
// MONITOR LOOP
// =====================================================

void monitorLoop()
{
  receiveData();

  delay(10);
}

// =====================================================
// MAIN LOOP
// =====================================================

void loop()
{
  if (sensorNode)
    sensorLoop();
  else
    monitorLoop();
}